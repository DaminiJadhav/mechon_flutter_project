class VehicleTypeAndId{

  String vehicleId;
  String vehicleType;

  VehicleTypeAndId({this.vehicleId,this.vehicleType});

}