class Constant{

  static final  String token = "Token";
  static final  String userId = "USERID";
  static final  String username = "USERNAME";
  static final  String NotificationData = "NOTIFICATIONDATA";
  static final  String garageId = "GARAGEID";



}